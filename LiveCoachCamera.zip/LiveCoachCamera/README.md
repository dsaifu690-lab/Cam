# Live Coach Camera

Open-source Android camera app. Live preview + your own Gemini API key = real-time
composition tips ("tilt down a little", "move left", "level the horizon").

## Get the APK
1. Push this folder to a GitHub repo (branch `main`).
2. Open the repo's **Actions** tab, then the latest **Build APK** run.
3. Download **LiveCoachCamera-debug-apk** under Artifacts, unzip, install the APK.

## Use
1. Open the app, allow the camera, paste your Gemini API key (free at aistudio.google.com/apikey).
2. Tap **Coach: ON** and point at your subject. Tips appear about every 2 to 3 seconds.
3. White circle = shutter. Photos save to Pictures/LiveCoach.

The key is stored only on your phone, never in the code. The model name is editable in
Settings (default `gemini-flash-latest`).
