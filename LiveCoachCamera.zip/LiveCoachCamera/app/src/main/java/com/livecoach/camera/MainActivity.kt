package com.livecoach.camera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CoachApp()
            }
        }
    }
}

private fun moveIcon(move: String): String = when (move) {
    "tilt_down" -> "⬇️"
    "tilt_up" -> "⬆️"
    "left" -> "⬅️"
    "right" -> "➡️"
    "closer" -> "➕"
    "back" -> "➖"
    "level" -> "↻"
    "good" -> "✅"
    else -> ""
}

private fun ImageProxy.toJpeg(): ByteArray {
    val bmp = toBitmap()
    val m = Matrix().apply { postRotate(imageInfo.rotationDegrees.toFloat()) }
    var out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    val longest = maxOf(out.width, out.height)
    if (longest > 768) {
        val s = 768f / longest
        out = Bitmap.createScaledBitmap(out, (out.width * s).toInt(), (out.height * s).toInt(), true)
    }
    val bos = ByteArrayOutputStream()
    out.compress(Bitmap.CompressFormat.JPEG, 70, bos)
    return bos.toByteArray()
}

private fun takePhoto(context: Context, ic: ImageCapture) {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "Coach_${System.currentTimeMillis()}")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/LiveCoach")
    }
    val opts = ImageCapture.OutputFileOptions.Builder(
        context.contentResolver,
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        values
    ).build()
    ic.takePicture(
        opts,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                Toast.makeText(context, "Saved to Pictures/LiveCoach", Toast.LENGTH_SHORT).show()
            }

            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(context, "Save failed: ${exception.message}", Toast.LENGTH_LONG).show()
            }
        }
    )
}

@Composable
fun CoachApp() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val prefs = remember { context.getSharedPreferences("coach", Context.MODE_PRIVATE) }

    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest") }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    var live by remember { mutableStateOf(false) }
    var tip by remember { mutableStateOf("Turn Coach ON and point at your subject") }
    var move by remember { mutableStateOf("") }
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }
    LaunchedEffect(Unit) {
        if (!hasPermission) launcher.launch(Manifest.permission.CAMERA)
    }

    val liveState = rememberUpdatedState(live)
    val keyState = rememberUpdatedState(apiKey)
    val modelState = rememberUpdatedState(model)
    val lastRun = remember { longArrayOf(0L) }
    val main = remember { Handler(Looper.getMainLooper()) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
    }

    // Runs on a background thread. While the network call is in progress,
    // CameraX drops frames (KEEP_ONLY_LATEST), so requests never pile up.
    val analyzer = remember {
        ImageAnalysis.Analyzer { proxy ->
            val now = System.currentTimeMillis()
            if (!liveState.value || keyState.value.isBlank() || now - lastRun[0] < 1500) {
                proxy.close()
                return@Analyzer
            }
            val jpeg = try {
                proxy.toJpeg()
            } catch (e: Exception) {
                null
            } finally {
                proxy.close()
            }
            if (jpeg == null) return@Analyzer

            val result = GeminiClient.coach(keyState.value, modelState.value, jpeg)
            lastRun[0] = System.currentTimeMillis()
            main.post {
                result.onSuccess {
                    tip = it.text
                    move = it.move
                }
                result.onFailure {
                    tip = "Error: ${it.message}"
                    move = ""
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermission) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val future = ProcessCameraProvider.getInstance(ctx)
                    future.addListener({
                        val provider = future.get()
                        val preview = Preview.Builder().build()
                            .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                        val analysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also { it.setAnalyzer(executor, analyzer) }
                        provider.unbindAll()
                        provider.bindToLifecycle(
                            activity,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            imageCapture,
                            analysis
                        )
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )
        } else {
            Text(
                "Camera permission needed",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Rule-of-thirds grid
        Canvas(Modifier.fillMaxSize()) {
            val c = Color.White.copy(alpha = 0.35f)
            for (i in 1..2) {
                val x = size.width * i / 3
                val y = size.height * i / 3
                drawLine(c, Offset(x, 0f), Offset(x, size.height), 2f)
                drawLine(c, Offset(0f, y), Offset(size.width, y), 2f)
            }
        }

        // Coaching tip
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(16.dp)
                .fillMaxWidth()
                .background(Color(0xCC000000), RoundedCornerShape(16.dp))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val icon = moveIcon(move)
            if (icon.isNotEmpty()) Text(icon, fontSize = 40.sp, color = Color.White)
            Text(
                tip,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                color = if (move == "good") Color(0xFF7CFC8A) else Color.White
            )
        }

        // Controls
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = { showSettings = true }) { Text("Settings") }

            Box(
                Modifier
                    .size(72.dp)
                    .background(Color.White, CircleShape)
                    .clickable { takePhoto(context, imageCapture) }
            )

            Button(onClick = {
                if (apiKey.isBlank()) {
                    showSettings = true
                } else {
                    live = !live
                    if (live) {
                        tip = "Looking…"
                    } else {
                        tip = "Coach paused"
                        move = ""
                    }
                }
            }) { Text(if (live) "Coach: ON" else "Coach: OFF") }
        }
    }

    if (showSettings) {
        var k by remember { mutableStateOf(apiKey) }
        var m by remember { mutableStateOf(model) }
        AlertDialog(
            onDismissRequest = { if (apiKey.isNotBlank()) showSettings = false },
            title = { Text("Settings") },
            text = {
                Column {
                    OutlinedTextField(
                        value = k,
                        onValueChange = { k = it },
                        label = { Text("Gemini API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = m,
                        onValueChange = { m = it },
                        label = { Text("Model") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    apiKey = k.trim()
                    model = m.trim().ifBlank { "gemini-flash-latest" }
                    prefs.edit().putString("key", apiKey).putString("model", model).apply()
                    showSettings = false
                }) { Text("Save") }
            }
        )
    }
}
