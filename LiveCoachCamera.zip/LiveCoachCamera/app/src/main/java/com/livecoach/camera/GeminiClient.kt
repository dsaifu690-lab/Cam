package com.livecoach.camera

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Tip(val text: String, val move: String)

object GeminiClient {

    private const val PROMPT =
        "You are a live camera composition coach looking at a phone viewfinder frame. " +
        "Give ONE short instruction (max 12 words) that would make the photo better. " +
        "Consider: tilting the phone up or down, moving left or right, stepping closer or back, " +
        "levelling the horizon, rule of thirds, headroom, lighting. " +
        "If the framing is already good, say so. " +
        "Reply ONLY as JSON: {\"tip\": string, \"move\": one of " +
        "\"tilt_down\",\"tilt_up\",\"left\",\"right\",\"closer\",\"back\",\"level\",\"good\"}"

    fun coach(apiKey: String, model: String, jpeg: ByteArray): Result<Tip> = runCatching {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")

        val image = JSONObject().put(
            "inline_data",
            JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
        )
        val parts = JSONArray().put(JSONObject().put("text", PROMPT)).put(image)
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json").put("temperature", 0.3)
            )

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 25000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey.trim())
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""

        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text
            }
            throw RuntimeException("HTTP $code: ${msg.take(100)}")
        }
        parse(text)
    }

    private fun parse(resp: String): Tip {
        val parts = JSONObject(resp)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val raw = sb.toString().replace("```json", "").replace("```", "").trim()
        return try {
            val j = JSONObject(raw)
            Tip(j.optString("tip", raw), j.optString("move", ""))
        } catch (e: Exception) {
            Tip(raw.take(80), "")
        }
    }
}
